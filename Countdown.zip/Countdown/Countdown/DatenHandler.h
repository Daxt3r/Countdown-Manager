#ifndef DATENHANDLER_H
#define DATENHANDLER_H

int PruefeUhrzeit(char *cString);
int PruefeTrue_or_False(char *cString);
void UpdateEintraege(struct tEigenschaften *pEigenschaften);

#endif
// Countdown.cpp: Hauptprojektdatei.
	
	//Version V0.2.2
	/*Beschreibung: Das Programm ermittelt die Differenz zwischen der aktuellen Uhrzeit und der vom Benutzer festgelegten Endzeit 
	                Der Benutzer kann festlegen, ob der Computer heruntergefahren werden soll oder nicht. Und mit welchen
					Einstellung er heruntergefahren werden soll. Die Einstellung vom Benutzer werden in einer Textdatei gespeichert.*/
	//Erstellt am: 07.03.2016
	//Autor: Marcel Crone


#include "StdAfx.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "util.h"
#include <Windows.h>

/* Was noch Implemnetiert werden soll */
/* + Multithreading, sodass Eingaben m�glich sind, jedochdie Uhrzeit weiterhin gemanaged werden kann
   + Hinzuf�gen von Eingaben, womit die Endzeit ver�ndert werden kann, eventuell noch ein Hilfemen� 
     und das Herunterfahren gemanaged werden kann (Ein/Ausstellen und Parameter festlegen) 
   + Textdatei hinzuf�gen, inder die Eingaben des Benutzers gespeichert werden und beim Starten des Programmes
     eingelesen werden*/

using namespace System;

struct tEigenschaften
{
	int nEndStd;
	int nEndMin;
};

/* forward decleration */
void FirstStartDialog(FILE *fpEigenschaften, struct tEigenschaften *pEigenschaften);
void EigenschaftenEinlesen(FILE *fpEigenschaften, struct tEigenschaften *pEigenschaften);
bool Countdown(struct tEigenschaften *pEigenschaften);

//-------------------------------------------------------------------------------------------------------------------------------
int main(array<System::String ^> ^args)
{
	FILE *fpEigenschaften;
	struct tEigenschaften pEigenschaften;
	
	fpEigenschaften = Open_File("Eigenschaften.txt", "r");
	if(fpEigenschaften == NULL)
		FirstStartDialog(fpEigenschaften, &pEigenschaften);
	else
		EigenschaftenEinlesen(fpEigenschaften, &pEigenschaften);
	
	while(!Countdown(&pEigenschaften))
	{
		Sleep(1000);
		system("cls");
	}

	system("shutdown.exe -s -t 15"); //Befehl um den Computer herunter zu fahren
    return 0;
}

//-------------------------------------------------------------------------------------------------------------------------------
//Das Programm wurde zum ersten Mal gestartet. Der Benutzer legt in dieser Funktion die Werte der Endzeit fest.
//Parameter: - *fpEigenschaften = Zeiger auf die Textdatei Eigenschaften.txt
//			 - *pEigenschaften  = Zeiger auf die Struktur tEigenschaften 
void FirstStartDialog(FILE *fpEigenschaften, struct tEigenschaften *pEigenschaften)
{
	char cUhrzeit[5];
	fpEigenschaften = Open_File("Eigenschaften.txt", "w"); //Eigenschaften Textdatei wird erstellt

	printf("Willkommen beim Countdown-Manager (CM)\n\n");
	printf("Dies ist Ihr erster Start des CM's. Daher muessen Sie zuerst ein\nPaar Eigenschaften fuer die Nutzung des CM's festlegen.\n\n");

	printf("Geben Sie die Uhrzeit (hh:mm) Ihres Arbeitsende ein: ");
	fgets(cUhrzeit, 6, stdin); //Die Endzeit wird vom Benutzer eingegeben

	pEigenschaften->nEndStd = atoi(strtok(cUhrzeit, ": ")); //Stunde wird vom Eingabe String getrennt
	pEigenschaften->nEndMin = atoi(strtok(NULL, " "));		//Minute wird vom Eingabe String getrennt

	fprintf(fpEigenschaften, "%d\n%d", pEigenschaften->nEndStd, pEigenschaften->nEndMin); //Die Uhrzeit wird in die Eigenschaftendatei geschrieben

	printf("Vielen Danke! Die Differenz bis zu Ihrem verdienten\nFeierabend wird Ihnen nun angezeigt.\n");
	system("PAUSE");

	fclose(fpEigenschaften);
	system("cls"); //Ausgaben in der Konsole werden gel�scht
}

//-------------------------------------------------------------------------------------------------------------------------------
//Die Funktion liest die Eigenschaften aus der Eigenschaften.txt Datei in die Struktur tEigenschaften ein
//Parameter: - *fpEigenschaften = Zeiger auf die Textdatei Eigenschaften.txt
//			 - *pEigenschaften  = Zeiger auf die Struktur tEigenschaften
void EigenschaftenEinlesen(FILE *fpEigenschaften, struct tEigenschaften *pEigenschaften)
{
	char cBuffer[30];

	fgets(cBuffer, sizeof(cBuffer), fpEigenschaften); //Stunde wird ausgelesen
	pEigenschaften->nEndStd = atoi(cBuffer);
	fgets(cBuffer, sizeof(cBuffer), fpEigenschaften); //Minute wird ausgelesen
	pEigenschaften->nEndMin = atoi(cBuffer);
}

//-------------------------------------------------------------------------------------------------------------------------------
//Die Funktion berechnet die Differenz zwischen der aktuellen Uhrzeit und der Endzeit und �berpr�ft ob die Endzeit erreicht wurde
//Parameter: - *pEigenschaften = Zeiger auf die Struktur tEigenschaften
//R�ckgabewert: - true  = Endzeit wurde erreicht
//				- false = Endzeit wurde noch nicht erreicht
bool Countdown(struct tEigenschaften *pEigenschaften)
{
	struct tm *tmnow;
	int tmp_std = 0, tmp_min = 0;

	time_t tnow;
	
	time(&tnow);
	tmnow = localtime(&tnow);
	
	tmp_min = pEigenschaften->nEndMin - tmnow->tm_min;  //Differenz zwischen Endminute und aktueller Minute wird berechnet
	if(tmp_min < 0) //Aktuelle Uhrzeit ist gr��er als Endzeit daher kleiner 0
	{
		tmp_min = tmp_min + 60;  //Differenz zwischen 60 Minuten und Endminute wird berechnet, da tmp_min kleiner 0 ist
		tmp_std = pEigenschaften->nEndStd - tmnow->tm_hour - 1; //Differenz zwischen Endstunde und aktueller Stunde wird berechnet -1 wenn Minuten gr��er als Endzeit
		if(tmp_std < 0)
			tmp_std = 0;
	}
	else
		tmp_std = pEigenschaften->nEndStd - tmnow->tm_hour; //Differenz zwischen Endstunde und aktueller Stunde wird berechnet		

	if(tmp_std == 0 && tmp_min == 0) //Wenn beides auf 0 ist, wurde die Endzeit erreicht
		return true;
	else
		printf("%.2d:%.2d\n", tmp_std, tmp_min); //Differenz wird ausgegeben

	return false;
}
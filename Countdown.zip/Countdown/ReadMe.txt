﻿========================================================================
    ANWENDUNG: Countdown-Projektübersicht
========================================================================

Diese Countdown-Anwendung wurde vom Anwendungs-Assistenten für Sie 
erstellt.

Diese Datei bietet eine Übersicht über den Inhalt der einzelnen Dateien, aus
denen Ihre Countdown-Anwendung besteht.

Countdown.vcxproj
    Dies ist die Hauptprojektdatei für VC++-Projekte, die mit dem 
    Anwendungs-Assistenten generiert werden. 
    Sie enthält Informationen über die Version von Visual C++, mit der die
    Datei generiert wurde, sowie über die Plattformen, Konfigurationen und 
    Projektfunktionen, die im Anwendungs-Assistenten ausgewählt wurden.

Countdown.vcxproj.filters
    Dies ist die Filterdatei für VC++-Projekte, die mithilfe eines 
    Anwendungs-Assistenten erstellt werden. 
    Sie enthält Informationen über die Zuordnung zwischen den Dateien im 
    Projekt und den Filtern. Diese Zuordnung wird in der IDE zur Darstellung 
    der Gruppierung von Dateien mit ähnlichen Erweiterungen unter einem 
    bestimmten Knoten verwendet (z. B. sind CPP-Dateien dem Filter 
    "Quelldateien" zugeordnet).

Countdown.cpp
    Dies ist die Hauptquelldatei der Anwendung.

AssemblyInfo.cpp
	Enthält benutzerdefinierte Attribute zum Ändern von Assemblymetadaten.

/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent weist Sie mit "TODO:" auf Teile des Quellcodes hin, 
die Sie ergänzen oder anpassen sollten.

/////////////////////////////////////////////////////////////////////////////
